import moment from 'moment';
if (typeof window !== 'undefined') {
    window.moment = moment;
}
