import moment from 'moment/moment';

moment.locale('ru');

export default moment;
