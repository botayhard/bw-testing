export default function ({ app, redirect, params }) {
    // console.log('test0', params.id);
    // app.$api.getProposal({ proposal: params.id }).then(({ result }) => {
    //     console.log('test', result);
    //     if (result === 'Proposal did not found') redirect('/proposals');
    // });
}
