const mixin = {
    props: {
        isPermament: { type: Boolean, default: false },
    },
};

export default mixin;
