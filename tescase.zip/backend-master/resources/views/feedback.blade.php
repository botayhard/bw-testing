<!DOCTYPE html>
<html>
<head>
    <title>{{ $subject }}</title>
    <meta charset="utf-8">
</head>
<body>
    Сообщение от {{ $name }} - {{ $from }}: <br>
    {{--Телефон: {{ $phone }}--}}
    {{ $message_text  }}
</body>
</html>
