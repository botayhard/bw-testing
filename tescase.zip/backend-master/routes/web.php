<?php

Route::get('/sitemap.xml', 'SitemapController@index');