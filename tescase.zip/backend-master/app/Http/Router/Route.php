<?php

namespace App\Http\Router;


class Route extends \Illuminate\Routing\Route
{

}