<?php

namespace App\Http\Router;


class RouteCollection extends \Illuminate\Routing\RouteCollection
{

}